let points = 0;
let cloudX = 0; // Posição inicial das nuvens
let sunY = 350; // Posição inicial do sol
let sunDirection = -1; // Direção do movimento do sol (subindo)
let wheatPositions = []; // Array para armazenar as posições do trigo

function setup() {
  createCanvas(400, 400);
  
  // Inicializando algumas posições para o trigo no chão
  for (let i = 0; i < 10; i++) {
    let wheatX = random(50, 350);
    let wheatY = random(250, 280);
    wheatPositions.push({x: wheatX, y: wheatY, isActive: true});
  }
}

function draw() {
  // Fundo azul para o céu (mudando de cor conforme o sol sobe)
  let skyColor = lerpColor(color(135, 206, 235), color(255, 150, 150), map(sunY, 350, 50, 0, 1));
  background(skyColor);
  
  // Sol (nascer do sol)
  fill(255, 204, 0);
  noStroke();
  ellipse(50, sunY, 80, 80);
  
  // Sol subindo
  sunY += sunDirection * 0.5; // Aumenta ou diminui a posição do sol
  
  // Impede o sol de sair da tela
  if (sunY < 50) {
    sunDirection = 1; // O sol começa a descer quando atingir o topo
  }
  if (sunY > 350) {
    sunDirection = -1; // O sol começa a subir quando atingir o chão
  }
  
  // Nuvens (animando a passagem no céu)
  fill(255, 255, 255, 150); // Cor branca com transparência
  noStroke();
  cloudX += 0.5; // Controlando a velocidade das nuvens
  ellipse(cloudX, 100, 100, 60);
  ellipse(cloudX + 150, 120, 120, 70);
  if (cloudX > width) {
    cloudX = -150; // Quando sair da tela, volta para a esquerda
  }
  
  // Chão verde
  fill(34, 139, 34);
  rect(0, 300, width, 100);
  
  // Árvores com frutas (laranjas e maçãs) no chão
  drawTree(100, 250, 'orange'); // Laranjas
  drawTree(300, 250, 'apple'); // Maçãs
  
  // Plantação de trigo (🌾)
  for (let i = 0; i < wheatPositions.length; i++) {
    if (wheatPositions[i].isActive) {
      drawWheat(wheatPositions[i].x, wheatPositions[i].y, i);
    }
  }
  
  // Desenha a Ovelhinha
  drawSheep(200, 350);
  
  // Mostrar pontos
  textSize(16);
  fill(0);
  text('Pontos: ' + points, 20, 20);
}

// Função para desenhar uma árvore com laranjas ou maçãs
function drawTree(x, y, fruitType) {
  // Tronco
  fill(139, 69, 19);
  rect(x, y, 30, 70);
  
  // Folhagem
  fill(34, 139, 34);
  ellipse(x + 15, y - 20, 100, 100); // Folhagem maior
  
  // Frutas (laranjas ou maçãs)
  if (fruitType === 'orange') {
    // Laranjas 🍊
    textSize(32);
    text('🍊', x + 10, y - 40);
    text('🍊', x + 40, y - 40);
    text('🍊', x + 15, y - 60);
  } else if (fruitType === 'apple') {
    // Maçãs 🍎
    textSize(32);
    text('🍎', x + 10, y - 40);
    text('🍎', x + 40, y - 40);
    text('🍎', x + 15, y - 60);
  }
}

// Função para desenhar a ovelhinha
function drawSheep(x, y) {
  // Ovelhinha com nome
  textSize(24);
  textAlign(CENTER);
  text('Ovelhinha', x, y - 40); // Nome acima da ovelha
  
  // Desenho da ovelha (emoji 🐑)
  textSize(50);
  text('🐑', x, y);
}

// Função para desenhar trigo (🌾)
function drawWheat(x, y, index) {
  textSize(32);
  text('🌾', x, y);
  
  // Verifica se o mouse passou sobre o trigo e conta pontos
  if (dist(mouseX, mouseY, x, y) < 20) {
    // Incrementa o contador de pontos e torna o trigo inativo
    if (wheatPositions[index].isActive) {
      points++; // Incrementa o contador de pontos
      wheatPositions[index].isActive = false; // Torna o trigo inativo
      setTimeout(() => {
        // Depois de um pequeno intervalo, cria um novo trigo em uma posição aleatória
        wheatPositions[index] = { x: random(50, 350), y: random(250, 280), isActive: true };
      }, 500); // O trigo reaparece após meio segundo
    }
  }
}
